How to Install:
1- Upload 'upload' folder containers ('verification' folder inside /public_html/)
2- Install .xml on Dashboard using Extension Installer
3- Voil�!

Author: danuel

You Like?! Donate some Bitcoin for this address
1JotTUvjgXndwQmSQgygQ8hgm16xiHAF4b[
