Export/Import Tool (V3.11) for OpenCart 1.5.1 to 1.5.6.x
========================================================

The Import/Export Tool allows the admin user to do a bulk export
of categories, products, options, attributes,filters and customers to an Excel spreadsheet file.
The spreadsheet file can be edited offline and then be re-imported to the OpenCart database.

The Import can be incremental, that is, data is updated or added to the OpenCart server.
Or it can be non-incremental which means all old data is first deleted before the Import.

The Export can be limited to certain data ranges only for products and categories.

Multiple languages are now supported, too.



Requirements and Limitations
============================

Memory requirements can be quite high.

Not every shared web hosting account supports a high process memory usage.
Therefore, if you use a basic shared web hosting account, no more than than a few thousands
products can be supported during an Export or Import at a time.

Also, a pre-installed VQmod is required, get it from <https://github.com/vqmod/vqmod/wiki>


Installation
============


Step 1) 
Upload the whole folders 'admin', 'system' and 'vqmod'
from the 'upload' directory to your remote OpenCart main directory.



Step 2) 
Before using this newly installed Export/Import feature for the first time, you must set the 
access rights for top administrator as follows:

In the admin interface, choose 

	System > Users > User Group

From there, select 'Top Administrator', then click on the 'Edit' link to the right. 
This will open up an edit window with multichoice dropdown lists for 'Access' and 'Modify' rights. 
In both of them, you'll see a new entry for 'tool/export_import' which you can select by clicking
on their check boxes.




Further help and customized versions
====================================

This tool has been successfully tested for a standard OpenCart 1.5.2.1 and 1.5.6.4.
It should also work for any other OpenCart version between 1.5.1 and 1.5.6.5.
Don't use other Opencart versions with this module.

If you need a customized version of the Export/Import Tool,
let us know and we can create one for a charge.

You can contact us at <http://www.mhccorp.com>

