<?php
// Heading
$_['heading_title']  = 'Чат Google Hangouts';

