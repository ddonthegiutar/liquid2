<?php
// Heading
$_['heading_title']    = 'Партнерский раздел';

// Text
$_['text_register']    = 'Регистрация';
$_['text_login']       = 'Вход';
$_['text_logout']      = 'Выход';
$_['text_forgotten']   = 'Забыли пароль?';
$_['text_account']     = 'Моя информация';
$_['text_edit']        = 'Редактировать персональную информацию';
$_['text_password']    = 'Пароль';
$_['text_payment']     = 'Способы оплаты';
$_['text_tracking']    = 'Реферальный код';
$_['text_transaction'] = 'Транзакции';


