<?php
/**
 * @version		$Id: google_analytics.php 4457 2016-10-05 10:04:36Z mic $
 * @package		Language Translation German Backend
 * @author		mic - https://osworx.net
 * @copyright	2016 OSWorX - https://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']		= 'Google Analytics';

// Text
$_['text_extension']	= 'Erweiterungen';
$_['text_success']		= 'Datensatz erfolgreich bearbeitet';
$_['text_signup']		= 'Anmelden im <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> Konot (oder kostenlos neu erstellen) und nach dem Profilerstellen den gesamten Code kopieren und in das Feld einfügen';
$_['text_default']		= 'Standard';

// Entry
$_['entry_code']		= 'Google Analytics Code';
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'Keine Rechte zum Bearbeiten';
$_['error_code']		= 'Code erforderlich';