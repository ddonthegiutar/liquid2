<?php
// Heading
$_['heading_title']         	  = 'Amazon EU';
$_['text_openbay']				  = 'OpenBay Pro';
$_['text_dashboard']			  = 'Amazon EU Dashboard';

// Text
$_['text_heading_settings'] 	  = 'Settings';
$_['text_heading_account'] 		  = 'Change plan';
$_['text_heading_links'] 		  = 'Item links';
$_['text_heading_register'] 	  = 'Register';
$_['text_heading_bulk_listing']   = 'Bulk listing';
$_['text_heading_stock_updates']  = 'Stock updates';
$_['text_heading_saved_listings'] = 'Saved listings';
$_['text_heading_bulk_linking']   = 'Bulk linking';