<?php
/**
 * @version		$Id: special.php 4457 2016-10-05 10:04:36Z mic $
 * @package		Language Translation German Backend
 * @author		mic - https://osworx.net
 * @copyright	2016 OSWorX - https://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

$_['heading_title']			= 'Angebote';

// Text
$_['text_extension']		= 'Erweiterungen';
$_['text_success']			= 'Datensatz erfolgreich bearbeitet';
$_['text_edit']				= 'Bearbeiten';
	// old
$_['text_module']			= 'Module';

// Entry
$_['entry_name']			= 'Name';
$_['entry_limit']			= 'Limit';
$_['entry_width']			= 'Breite (px)';
$_['entry_height']			= 'Höhe (px)';
$_['entry_status']			= 'Status';

// Error
$_['error_permission']		= 'Keine Rechte für diese Aktion';
$_['error_name']			= 'Name muß zwischen 3 und 64 Zeichen lang sein';
$_['error_width']			= 'Breite erforderlich';
$_['error_height']			= 'Höhe erforderlich';