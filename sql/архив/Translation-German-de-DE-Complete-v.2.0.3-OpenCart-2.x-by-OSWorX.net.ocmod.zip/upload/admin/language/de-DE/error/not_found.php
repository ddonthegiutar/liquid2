<?php
/**
 * @version		$Id: not_found.php 4455 2016-10-04 09:51:37Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Seite nicht gefunden';

// Text
$_['text_not_found']	= 'Die angeforderte Seite konnte leider nicht gefunden werden.<br />Sollte das Problem weiterhin bestehen, bitte die Shopverwaltung davon informieren (siehe Kontakt) - vielen Dank.';