<?php
/**
 * @version		$Id: footer.php 4455 2016-10-04 09:51:37Z mic $
 * @package		Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */
// Text
$_['text_footer'] = '<a href="http://www.opencart.com" target="_blank">OpenCart</a> &copy; 2009-' . date('Y') . ' Alle Rechte vorbehalten.<br />Dt. Version &copy; <a href="http://osworx.net" target="_blank">OSWorX</a>';
$_['text_version']= 'Version %s';