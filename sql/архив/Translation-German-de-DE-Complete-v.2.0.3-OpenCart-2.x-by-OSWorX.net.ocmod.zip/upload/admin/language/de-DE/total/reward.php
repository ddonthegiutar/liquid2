<?php
/**
 * @version		$Id: reward.php 4343 2016-06-01 10:18:23Z mic $
 * @package		Language Language Translation German Backend
 * @author		mic - http://osworx.net
 * @copyright	2014 OSWorX - http://osworx.net
 * @license		GPL - www.gnu.org/copyleft/gpl.html
 */

// Heading
$_['heading_title']		= 'Bonuspunkte';

// Text
$_['text_total']		= 'Kassamodule';
$_['text_success']		= 'Einstellungen erfolgreich bearbeitet';
$_['text_edit']			= 'Bearbeiten';

// Entry
$_['entry_status']		= 'Status';
$_['entry_sort_order']	= 'Reihenfolge';

// Error
$_['error_permission']	= 'Keine Rechte für diese Aktion';