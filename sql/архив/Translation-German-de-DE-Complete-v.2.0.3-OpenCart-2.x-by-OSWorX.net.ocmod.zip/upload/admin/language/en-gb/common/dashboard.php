<?php
// Heading
$_['heading_title'] = 'Dashboard';

// Error
$_['error_install']	= '<p>Note: the Install folder still exists!<br />For security reasons either delete this folder or rename and set permissions to 0644.</p><div class="well well-sm" style="font-size: 1.1em; margin: 10px;"><p>Avoid cease and desist letters, as well as expensive punishments etc. >> <b>make your shop save!</b></p><p>Integrate current legal rules and advices with a few mouseclicks.<br />Simply with <b>LEGAL</b> - the legal module from <a href="https://osworx.net?ref=firstCall" target="_blank">OSWorX</a></p></div>';