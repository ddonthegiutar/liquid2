<?php
/**
 * @version		$Id: install.php 4465 2016-10-11 13:44:02Z mic $
 * @package		Postinstaller Translation
 * @author		mic - https://osworx.net
 * @copyright	2016 OSWorX - https://osworx.net
 * @license		OCL OSWorX Commercial License - https://osworx.net
 */

define( 'LANGUAGE_POST_INSTALL', true );
include_once( str_replace( 'admin/', '', DIR_APPLICATION ) . 'install/install_language.php' );