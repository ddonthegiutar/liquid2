<?php
// Text
$_['text_title'] = 'Кредитная / Дебетная карта (Payza)';
?>