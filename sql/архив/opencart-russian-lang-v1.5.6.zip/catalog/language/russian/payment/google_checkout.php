<?php
// Entry
$_['text_title']     = 'Кредитная карта / Дебетовая карта (Google Checkout)';

// Error
$_['error_shipping'] = 'Укажите способ доставки!';
?>