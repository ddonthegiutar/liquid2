<?php
// Heading
$_['heading_title'] = 'Уточнение поиска';
?>