<?php
// Heading 
$_['heading_title'] = 'Корзина покупок';

// Text
$_['text_items']    = 'Товаров: %s (%s)';
$_['text_empty']    = 'Ничего не куплено!';
$_['text_cart']     = 'Просмотр корзины';
$_['text_checkout'] = 'Оформление заказа';

$_['text_payment_profile'] = 'Платёжный профиль';
?>