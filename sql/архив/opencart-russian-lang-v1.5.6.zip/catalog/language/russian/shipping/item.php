<?php
// Text
$_['text_title']       = 'За единицу';
$_['text_description'] = 'Стоимость доставки за единицу товара';
?>