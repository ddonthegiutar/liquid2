<?php
// Heading
$_['heading_title'] = 'Выход из Кабинета Партнера';

// Text
$_['text_message']  = '<p>Вы вышли из Кабинета Партнера.</p>';
$_['text_account']  = 'Кабинет Партнера';
$_['text_logout']   = 'Выход';
?>