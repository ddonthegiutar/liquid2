<?php
// Heading
$_['heading_title']      = 'SagePay';

// Text
$_['text_payment']       = 'Оплата';
$_['text_success']       = 'Настройки модуля обновлены!';
$_['text_sagepay']       = '<a href="https://support.sagepay.com/apply/default.aspx?PartnerID=E511AF91-E4A0-42DE-80B0-09C981A3FB61" target="_blank"><img src="view/image/payment/sagepay.png" alt="SagePay" title="SagePay" style="border: 1px solid #EEEEEE;" /></a>';
$_['text_sim']           = 'Simulator';
$_['text_test']          = 'Test';
$_['text_live']          = 'Live';
$_['text_defered']       = 'Defered';
$_['text_authenticate']  = 'Authenticate';

// Entry
$_['entry_vendor']       = 'Vendor:';
$_['entry_password']     = 'Пароль:';
$_['entry_test']         = 'Тестовый режим:';
$_['entry_transaction']  = 'Transaction Method:';
$_['entry_total']        = 'Минимальная сумма заказа:<br /><span class="help">Сумма заказа, после достижения которой данный способ станет доступен.</span>';
$_['entry_order_status'] = 'Статус заказа:';
$_['entry_geo_zone']     = 'Географическая зона:';
$_['entry_status']       = 'Статус:';
$_['entry_sort_order']	 = 'Порядок сортировки:';

// Error
$_['error_permission']   = 'У Вас нет прав для управления этим модулем!';
$_['error_vendor']       = 'Укажите Vendor ID!';
$_['error_password']     = 'Укажите пароль!';
?>