<?php
// Heading 
$_['heading_title']    = 'Управление модулями';

// Text
$_['text_success']     = 'Модуль успешно установлен!';

// Error
$_['error_permission'] = 'У Вас нет прав для управления этим модулем!';
$_['error_upload']     = 'Укажите файл для загрузки!';
$_['error_filetype']   = 'Недопустимый тип файла!';
?>