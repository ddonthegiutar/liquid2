As they say - the convenience is made up of little things.

EnableDisable Products module simplifies the process of working with the goods, adding Enable/Disable buttons for batch processing.

Also possible to activate / deactivate all products by pressing a single button, plus a couple of pleasant things.


Features:
- enable / disable selected products by pressing a one button
- enable / disable ALL goods of a single click
- reset of all filters by pressing Clear button*
- added data processing for Filters by pressing Enter key (default - only pressing the button Filter)*
-----
* only for Opencart 2.x

- don't change any files (all changes through VQMOD/OCMOD)
- don't create additional fields and tables in the DB
- compatibility with Opencart versions 1.5.x or higher (including 2.x)
- requires VQMOD for versions below 2.0
- uses OCMOD for 2.x version


Install 1.5.x:
---------
To install just copy xml file into vqmod/xml directory

Install 2.x:
---------
Just upload ocmod.xml file in Extension Installer

Don`t forget refresh modification cache after install!


=======================
Thanks for your choise!

If you liked this module - please rate it on module page

More extensions:
https://www.opencart.com/index.php?route=marketplace/extension&filter_member=AlexDW